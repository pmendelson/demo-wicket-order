/**
 * Utility objects for CSV, JSON and XML processing.
 */
package com.avaje.ebean.text;