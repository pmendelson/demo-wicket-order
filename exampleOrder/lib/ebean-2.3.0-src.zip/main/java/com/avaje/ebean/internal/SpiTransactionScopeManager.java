package com.avaje.ebean.internal;

public interface SpiTransactionScopeManager {

	public void replace(SpiTransaction t);
}
