/**
 * Copyright (C) 2006  Robin Bygrave
 * 
 * This file is part of Ebean.
 * 
 * Ebean is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *  
 * Ebean is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with Ebean; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA  
 */
package com.avaje.ebean.server.el;

import com.avaje.ebean.server.deploy.BeanProperty;
import com.avaje.ebean.text.StringParser;

/**
 * The expression language object that can get values.
 * <p>
 * This can be used for local sorting and filtering.
 * </p>
 */
public interface ElPropertyValue extends ElPropertyDeploy {

	/**
	 * Return the Id values for the given bean value.
	 */
	public Object[] getAssocOneIdValues(Object bean);

	/**
	 * Return the Id expression string.
	 * <p>
	 * Typically used to produce id = ? expression strings.
	 * </p>
	 */
	public String getAssocOneIdExpr(String prefix, String operator);

	/**
	 * Return true if this is an ManyToOne or OneToOne associated bean property.
	 */
	public boolean isAssocOneId();

	/**
	 * Return the underlying bean property.
	 */
	public BeanProperty getBeanProperty();

	/**
	 * Return the default StringParser for the scalar property.
	 */
	public StringParser getStringParser();

	/**
	 * Return true if the last type is "DateTime capable" - can support
	 * {@link #parseDateTime(long)}.
	 */
	public boolean isDateTimeCapable();

	/**
	 * For DateTime capable scalar types convert the long systemTimeMillis into
	 * an appropriate java time (Date,Timestamp,Time,Calendar, JODA type etc).
	 */
	public Object parseDateTime(long systemTimeMillis);

	/**
	 * Return the value from a given entity bean.
	 */
	public Object elGetValue(Object bean);

	/**
	 * Return the value ensuring objects prior to the top
	 * scalar property are automatically populated.
	 */
	public Object elGetReference(Object bean);

	/**
	 * Set a value given a root level bean.
	 * <p>
	 * If populate then 
	 * </p>
	 */
	public void elSetValue(Object bean, Object value, boolean populate, boolean reference);

	/**
	 * Make the owning bean of this property a reference (as in not new/dirty).
	 */
	public void elSetReference(Object bean);

	/**
	 * Convert the value to the expected type.
	 * <p>
	 * Typically useful for converting strings to the appropriate number type
	 * etc.
	 * </p>
	 */
	public Object elConvertType(Object value);
}
